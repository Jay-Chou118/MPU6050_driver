#ifndef __BSP_IWDG_H__
#define __BSP_IWDG_H__

#include <stm32f10x.h>

void IWDG_Configuration(void);
void IWDG_FeedDog(void);

#endif
