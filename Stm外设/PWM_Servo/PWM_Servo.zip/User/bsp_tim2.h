#ifndef __BSP_TIM2_H__
#define __BSP_TIM2_H__

#include <stm32f10x.h>
#include "Led_Key.h"

void TIM2_BaseConfiguration(void);
void TIM2_PWM_Configuration(void);

#endif
